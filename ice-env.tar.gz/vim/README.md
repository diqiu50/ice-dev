##在用户根目录下直接克隆。

```
git clone https://github.com/wuxiwei/vim.git
```
##将vim\\.vimrc文件剪切到用户根目录下

```
mv vim/.vimrc ./
```
##修改vim文件夹的名称为.vim

```
mv vim .vim
```

##大功告成
